package com.eventapp.dto;

public class Payload {
	
}
