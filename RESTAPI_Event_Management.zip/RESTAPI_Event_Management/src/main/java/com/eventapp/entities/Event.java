package com.eventapp.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="event")
public class Event {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id ;
	
	@Column(length =25)  
	@NotBlank(message = "mandatory")
	private String name ;    
	
	@NotBlank(message = "mandatory")
	@Column(length =25)  
	private String city ;
	
	private LocalDate date_of_Booking;
	
	@Enumerated(EnumType.STRING)
	@NotNull(message = "mandatory")
	@Column(length=25)
	private EventType eventType;
	
	@Column(length =10) 
	@NotBlank(message = "mandatory")
	private String contactNo;
	
	@NotNull(message = "mandatory")
	private double budget ;
	
	
}
