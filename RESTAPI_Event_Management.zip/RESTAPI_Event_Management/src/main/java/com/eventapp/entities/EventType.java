package com.eventapp.entities;

public enum EventType {
	WEDDING , FESTIVAL , EVENT , CHRITY ;
}
