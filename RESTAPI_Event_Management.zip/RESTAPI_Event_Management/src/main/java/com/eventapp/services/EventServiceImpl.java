package com.eventapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eventapp.entities.Event;
import com.eventapp.repositories.EventRepo;

@Service
@Transactional
public class EventServiceImpl implements EventService {

	@Autowired
	private EventRepo eventrepo ;
	
	@Override
	public List<Event> display() {
		return eventrepo.findAll();
	}

	@Override
	public Event addEvent(Event newevent) {
		return eventrepo.save(newevent);	
	}

	@Override
	public String deleteEvent(Long id) {
		if(eventrepo.existsById(id)) {
			eventrepo.deleteById(id);
			return "deleted successfully";
		}
		return "Invalid id";
	}

	@Override
	public String updateEvent(Long id, Event updateevent) {
		if(eventrepo.existsById(id)) {
			eventrepo.save(updateevent);
			return "Updated successfully";
		}
		return "Invalid id";
	}

	@Override
	public Event searchEvent(String city) {
		return eventrepo.getByCity(city);
	}

}
