package com.eventapp.services;

import java.util.List;

import com.eventapp.entities.Event;

public interface EventService {
	
	List<Event> display();
	
	Event addEvent(Event newevent);
	
	String deleteEvent(Long id);
	
	String updateEvent(Long id , Event updateevent);
	
	Event searchEvent(String city);
	
}
