package com.eventapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eventapp.entities.Event;

public interface EventRepo extends JpaRepository<Event, Long> {

	@Query("select e from Event e where e.city=:city")
	Event getByCity(String city);
}
