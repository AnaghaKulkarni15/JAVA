package com.eventapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eventapp.entities.Event;
import com.eventapp.services.EventService;

@RestController
@RequestMapping("/event")
public class EventController {
	
	@Autowired
	EventService eventservice ;
	
	@GetMapping
	public List<Event> GetAll(){
		return eventservice.display();
	}
	
	@PostMapping
	public Event addNewEvent(Event event) {
		return eventservice.addEvent(event);
	}
	
	@DeleteMapping("/{id}")
	public String removeEvent(Long id) {
		return eventservice.deleteEvent(id);
	}
	
	@PutMapping("/{id}")
	public String updateEventById(Long id , Event event) {
		return eventservice.updateEvent(id, event);
	}
	
	@GetMapping("/{city}")
	public Event GetByCity(String city) {
		return eventservice.searchEvent(city);
	}
	
	
	
}
