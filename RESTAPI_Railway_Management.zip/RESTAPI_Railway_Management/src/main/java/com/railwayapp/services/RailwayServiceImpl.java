package com.railwayapp.services;

import java.util.List;

//import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.railwayapp.entities.Category;
import com.railwayapp.entities.Railway;
import com.railwayapp.repositories.RailwayRepo;

@Service
@Transactional
public class RailwayServiceImpl implements RailwayService {
	
	@Autowired 
	private RailwayRepo railwayrepo ;

	@Override
	public List<Railway> display() {
		return railwayrepo.findAll();
	}

	@Override
	public Railway addRailway(Railway newrailway) {
		return railwayrepo.save(newrailway);
	}

	@Override
	public String deleteRailway(Long id) {
		if(railwayrepo.existsById(id)) {
			railwayrepo.deleteById(id);
			return "deleted successfully";
		}
		return "Invalid id";
	}

	@Override
	public String updateRailway(Long id, Railway updateRailway) {
		if(railwayrepo.existsById(id)) {
			railwayrepo.save(updateRailway);
			return "updated successfully";
		}
		return "Invalid id";
	}

	@Override
	public Railway searchByCategory(Category category) {
		return railwayrepo.byCategory(category);
	}

}
