package com.railwayapp.services;

import java.util.List;

import com.railwayapp.entities.Category;
import com.railwayapp.entities.Railway;

public interface RailwayService {
	
	List<Railway> display();
	
	Railway addRailway(Railway newrailway);
	
	String deleteRailway(Long id);
	
	String updateRailway(Long id , Railway updateRailway);
	
	Railway searchByCategory(Category category);

}
