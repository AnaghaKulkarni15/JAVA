package com.railwayapp.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="railway")
public class Railway {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id ;
	
	@Column(length=25)
	@NotBlank(message = "mandatory")
	private String name ;
	
	@Enumerated(EnumType.STRING)
	@NotNull(message = "mandatory")
	@Column(length=25)
	private Category category ;
	
	private LocalDateTime start_time;
	
	private LocalDateTime end_time ;
	
	@NotBlank(message = "mandatory")
	@Column(length=25)
	private String src , dest ;
	
	@NotNull(message = "mandatory")
	@Column(length=20)
	private int station_code;
	
	@NotNull(message = "mandatory")
	@Column(length=20)
	private int dist , freq ;
}
