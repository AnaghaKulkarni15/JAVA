package com.railwayapp.entities;

public enum Category {
	EXPRESS , SHATABDI , AC , METRO ;
}
