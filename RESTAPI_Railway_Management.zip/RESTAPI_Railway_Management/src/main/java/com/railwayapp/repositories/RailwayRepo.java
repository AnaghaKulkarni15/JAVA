package com.railwayapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.railwayapp.entities.Category;
import com.railwayapp.entities.Railway;

public interface RailwayRepo extends JpaRepository<Railway, Long> {
	
	@Query("select r from Railway r where r.category=:cat")
	Railway byCategory(Category cat);

	//Railway FindByCategory(Category category);
}
