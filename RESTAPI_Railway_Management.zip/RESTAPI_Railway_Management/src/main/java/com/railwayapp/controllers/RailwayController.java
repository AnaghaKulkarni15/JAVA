package com.railwayapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.railwayapp.entities.Category;
import com.railwayapp.entities.Railway;
import com.railwayapp.services.RailwayService;

//import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/railway")
public class RailwayController {
	
	@Autowired
	private RailwayService railwayservice;
	
	@GetMapping
	public List<Railway> GetAll(){
		return railwayservice.display();
	}
	
	@PostMapping
	public Railway addNewRailway(@RequestBody Railway railway) {
		return railwayservice.addRailway(railway);
	}
	
	@DeleteMapping("/{id}")
	public String deleteById(@PathVariable Long id) {
		return railwayservice.deleteRailway(id);
	}
	
	@PutMapping("/{id}")
	public String updateExistingRailway(@PathVariable Long id , @RequestBody Railway railway) {
		return railwayservice.updateRailway(id, railway);
	}
	
	@GetMapping("/{category}")
	public Railway GetByCategory(@PathVariable Category category) {
		return railwayservice.searchByCategory(category);
	}
	
}
