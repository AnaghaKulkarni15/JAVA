package com.railwayapp.dto;

import java.time.LocalDateTime;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import com.railwayapp.entities.Category;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Payload {
	@NotBlank(message="Mandatory")
	private String name ;
	
	@NotNull(message="Mandatory")
	@Enumerated(EnumType.STRING)
	private Category category ;
	
	@Past
	private LocalDateTime strt_time;
	
	private LocalDateTime end_date;
	
	@NotNull(message="Mandatory")
	private int fee ;
}
